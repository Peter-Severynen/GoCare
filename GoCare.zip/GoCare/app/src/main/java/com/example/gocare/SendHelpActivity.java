package com.example.gocare;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class SendHelpActivity extends AppCompatActivity {

    private enum Sex
    {
        MALE, FEMALE;
    }

    private Button M_Button;
    private Button F_Button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_send_help);
    }

    public void M_ButtonClick(View view) {
        //when you click left button do this:
        Button M_Button = (Button) findViewById(R.id.M_Button);
        Sex sex = Sex.MALE;
    }

    public void F_ButtonClick(View view) {
        //when you click left button do this:
        Button F_Button = (Button) findViewById(R.id.F_Button);
        Sex sex = Sex.FEMALE;
    }
}
