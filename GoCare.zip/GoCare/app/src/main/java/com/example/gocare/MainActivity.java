package com.example.gocare;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private Button Send_Help_Button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    public void Send_Help_ButtonClick(View view) {
        //when you click left button do this:
        Button Send_Help_Button = (Button) findViewById(R.id.Send_Help_Button);
        //your code goes here
    }
}
